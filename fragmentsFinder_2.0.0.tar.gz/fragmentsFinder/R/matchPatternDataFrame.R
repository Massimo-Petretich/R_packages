matchPatternDataFrame <- function(dict0,seqname,genome, mismatches) {
	subject <- genome[[seqname]]
	hits <- data.frame(seqname=NA, start=NA, end=NA,strand=NA, patternID=NA, check.names=FALSE)

	for (i in seq_len(length(dict0))) {
		patternID       <- names(dict0)[i]
		pattern         <- dict0[[i]]
		plus_matches    <- matchPattern(pattern, subject, max.mismatch=mismatches)
		names(plus_matches) <- rep.int(patternID, length(plus_matches))
		hits            <- rbind(hits, writeHits(seqname, plus_matches, "+"))
            
		rcpattern       <- reverseComplement(pattern)
 		minus_matches   <- matchPattern(rcpattern, subject, max.mismatch=mismatches)
		names(minus_matches) <- rep.int(patternID, length(minus_matches))
		hits            <- rbind(hits, writeHits(seqname, minus_matches, "-"))
	}
	
	return(hits[complete.cases(hits),])
}
