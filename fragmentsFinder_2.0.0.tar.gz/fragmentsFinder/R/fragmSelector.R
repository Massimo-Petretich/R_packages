fragmSelector <- function (range, pattern1, pattern2, genome, ...) {
  argnames <- names(list(...))
  addArgs <- list(...)
  
  mpDF1 <- patternScan(range, pattern1, genome) 
  mpDF2 <- patternScan(range, pattern2, genome) 
  mpDF <- rbind(mpDF1, mpDF2)
  mpDF <- mpDF[order(mpDF$start), ]
  rownames(mpDF) <- paste("fragment", 1:nrow(mpDF), sep = "")
  
  mpDF$patternEnd <- c(mpDF$pattern[2:nrow(mpDF)], NA) 
  mpDF$end <- c(mpDF$end[2:nrow(mpDF)], NA)
  mpDF <- mpDF[mpDF$pattern != mpDF$patternEnd & !is.na(mpDF$patternEnd), c(1:3, 5:6)]
  colnames(mpDF)[4] <- "patternStart"
  
  mpDF$fragmentName <- rownames(mpDF)
  
  rgDF <- as(UCSCtoGRanges(range), "data.frame")
  rgDF$seqnames <- as.character(rgDF$seqnames)
  
  mpDF<-mpDF[mpDF$end-mpDF$start>sapply(strsplit(paste0(mpDF$patternStart, mpDF$patternEnd), ""), length), ]
  mpGR1<-GRanges(seqnames=mpDF1$chr[1:(nrow(mpDF1)-1)], ranges=IRanges(mpDF1$start[1:(nrow(mpDF1)-1)], mpDF1$end[2:nrow(mpDF1)]), pattern=mpDF1$pattern[1:(nrow(mpDF1)-1)])
  mpGR<-GRanges(seqnames=mpDF$chr, ranges=IRanges(mpDF$start+sapply(strsplit(mpDF$patternStart,""),length), mpDF$end-sapply(strsplit(mpDF$patternEnd,""), length)), patternStart=mpDF$patternStart,patternEnd=mpDF$patternEnd)
  mpDF$pattern1Fragment<-rep(NA, nrow(mpDF))
  mpDF$pattern1Fragment[queryHits(findOverlaps(mpGR,mpGR1))]<-width(mpGR1[subjectHits(findOverlaps(mpGR,mpGR1))])
  
  
  return(mpDF[complete.cases(mpDF),])
}
