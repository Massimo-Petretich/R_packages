writeHits <- function(seqname, matches, strand) {
    hits <- data.frame( seqname=rep.int(seqname, length(matches)),
                        start=start(matches),
                        end=end(matches),
                        strand=rep.int(strand, length(matches)),
                        patternID=names(matches),
                        check.names=FALSE
                        )
}
