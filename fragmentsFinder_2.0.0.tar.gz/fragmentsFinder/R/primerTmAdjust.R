primerTmAdjust <- function(fragments, Tm, clippingCycles, ...){
  
  argnames <- names(list(...))
  addArgs <- list(...)
  
  clipped <- lapply(1:clippingCycles, function(n, fragments) {fragments$primerPattern1 <- sapply(1:nrow(fragments), function(i, n, fragments) paste(strsplit(fragments$primerPattern1[i], split = "")[[1]][- seq(from = 1, to = n)], collapse = ""), n = n, fragments = fragments); fragments}, fragments = fragments)
  
  clipped2 <- lapply(clipped, fragmentSummaryPart1)
  
  fragments <- fragmentSummaryPart1(fragments)
  
  clipped2 <- c(list(fragments), clipped2)
  
  clippedIndexes <- apply(X = sapply(clipped2, function(x) Tm - x$Tm), MARGIN = 1, FUN = function(x) which((0-x)^2 == min((0-x)^2)))
  
  clipped3 <- do.call("rbind", lapply(1:nrow(fragments), function(nr, ci) clipped2[[ci[nr]]][nr, ], ci = clippedIndexes))
  
  return(clipped3)
  
}