fragmRange <- function (range, pattern1, pattern2, genome, ...) {
    argnames <- names(list(...)); addArgs <- list(...)
    primerLength <- ifelse("primerLength" %in% argnames, ifelse(is.numeric(addArgs$primerLength), addArgs$primerLength, 20), 20)
    
    mpDF1 <- patternScan(range, pattern1, genome) 
    mpDF2 <- patternScan(range, pattern2, genome) 
    mpDF <- rbind(mpDF1, mpDF2)
    mpDF <- mpDF[order(mpDF$start), ]
    
    mpDF$patternEnd <- c(mpDF$pattern[2:nrow(mpDF)], NA)
    mpDF$end <- c(mpDF$end[2:nrow(mpDF)], NA)
    
    mpDF[,4] <- mpDF[,3]-mpDF[,2]
    colnames(mpDF)[5] <- "patternStart"
    rownames(mpDF) <- paste("fragment", 1:nrow(mpDF), sep = "")
    
    return(mpDF[complete.cases(mpDF),])
}
