patternScan <- function(range, pattern, genome) {

        rgDF<-as(UCSCtoGRanges(range), "data.frame"); rgDF$seqnames <- as.character(rgDF$seqnames)
        chr<-noquote(rgDF[1,1])
        chrI<-eval(parse(text=paste("genome$",chr, sep="")))

        mp <- matchPattern(pattern, chrI, max.mismatch=0)
        mpDF <- data.frame(chr=rep(rgDF$seqnames, times=length(mp)), start=start(mp), end=end(mp),width=width(mp), pattern=rep(pattern, times=length(mp)), stringsAsFactors = FALSE)
        mpDF <- mpDF[mpDF$start>=rgDF$start & mpDF$end<=rgDF$end,]
}
