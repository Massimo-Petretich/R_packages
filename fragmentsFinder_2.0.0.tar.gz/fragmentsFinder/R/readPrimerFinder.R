readPrimerFinder <- function (fragments, pattern1, pattern2, genome, ...) {
    argnames <- names(list(...))
    addArgs <- list(...)
    primerLength <- ifelse("primerLength" %in% argnames, ifelse(is.numeric(addArgs$primerLength), addArgs$primerLength, 22), 22)

    
    
    chrI <- eval(parse(text = paste("genome$", noquote(fragments[1,1]), sep = ""))) 
    
    fragments$primerPattern1 <-  sapply(1:nrow(fragments), 
                                        function(i) ifelse(
                                          fragments$patternStart[i] == pattern1, 
                                          as.character(reverseComplement(chrI[fragments$start[i]:(fragments$start[i] + primerLength - 1)])), 
                                          as.character(chrI[(fragments$end[i] - primerLength + 1):(fragments$end[i])])
                                          )
                                        )
    
    return(fragments[complete.cases(fragments),])
}
