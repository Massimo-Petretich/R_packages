filterFragments <- function(fragments, ...) {
  argnames <- names(list(...)); addArgs <- list(...)
  
  minFragmentLengthPattern1Only <- ifelse("minFragmentLengthPattern1Only" %in% argnames,  ifelse(is.numeric(addArgs$minFragmentLengthPattern1Only), addArgs$minFragmentLengthPattern1Only, 500), 500)
  minFragmentLength <- ifelse("minFragmentLength" %in% argnames,  ifelse(is.numeric(addArgs$minFragmentLength), addArgs$minFragmentLength, 300), 300)
  minGCpercentage   <- ifelse("minGCpercentage" %in% argnames,    ifelse(is.numeric(addArgs$minGCpercentage),   addArgs$minGCpercentage,   30),  30)
  maxGCpercentage   <- ifelse("maxGCpercentage" %in% argnames,    ifelse(is.numeric(addArgs$maxGCpercentage),   addArgs$maxGCpercentage,   70),  70)
  maxGenomicMatches <- ifelse("maxGenomicMatches" %in% argnames,  ifelse(is.numeric(addArgs$maxGenomicMatches), addArgs$maxGenomicMatches, 1),   1)
  maxGenomicMatches1Mismatch   <- ifelse("maxGenomicMatches1Mismatch" %in% argnames,ifelse(is.numeric(addArgs$maxGenomicMatches1Mismatch), addArgs$maxGenomicMatches1Mismatch, 10),   10)
  maxGenomicMatches2Mismatches <- ifelse("maxGenomicMatches2Mismatches" %in% argnames,ifelse(is.numeric(addArgs$maxGenomicMatches2Mismatches), addArgs$maxGenomicMatches2Mismatches, 30),   30)
  maxTm   <- ifelse("maxTm" %in% argnames,ifelse(is.numeric(addArgs$maxTm), addArgs$maxTm, 65),   65)
  minTm   <- ifelse("minTm" %in% argnames,ifelse(is.numeric(addArgs$minTm), addArgs$minTm, 45),   45)
 
  cat(    
    "Total Fragments: ", nrow(fragments), "\n\n",
    "Rejected Fragments:\n",
    "Low GC content: ", sum(fragments$GC < nchar(fragments$primerPattern1) * minGCpercentage/100), "\n",
    "High GC content: ", sum(fragments$GC > nchar(fragments$primerPattern1) * maxGCpercentage/100), "\n",
    "Low fragment length: ", sum(fragments$fragmentLength < minFragmentLength), "\n",
    "Low fragment length (pattern1 only): ", sum(fragments$pattern1Fragment < minFragmentLengthPattern1Only), "\n",
    "Low Tm: ",  sum(fragments$Tm < minTm), "\n",
    "High Tm: ", sum(fragments$Tm > maxTm), "\n"
  )
  
  
  fragments <- fragments[ 
      fragments$GC >= nchar(fragments$primerPattern1) * minGCpercentage/100 & 
      fragments$GC <= nchar(fragments$primerPattern1) * maxGCpercentage/100 & 
      fragments$fragmentLength >= minFragmentLength & 
      fragments$pattern1Fragment >= minFragmentLengthPattern1Only &
      fragments$Tm < maxTm & 
      fragments$Tm > minTm
    ,]
  
  if (length(grep("genomicMatches", colnames(fragments))) != 0) {
    cat("Genomic matches > ", maxGenomicMatches, ": ",  sum(fragments$genomicMatches > maxGenomicMatches),"\n")
    fragments <- fragments[fragments$genomicMatches <= maxGenomicMatches, ]
  }
  
  if (length(grep("1Mi", colnames(fragments))) != 0) {
    cat ("Genomic matches 1 Mismatch > ", maxGenomicMatches1Mismatch, ": ",  sum(fragments$genomicMatches1Mismatch > maxGenomicMatches1Mismatch),"\n")
    fragments <- fragments[fragments$genomicMatches1Mismatch<=maxGenomicMatches1Mismatch,]
  }
  
  if (length(grep("2Mi", colnames(fragments))) != 0) {
    cat ("Genomic matches 2 Mismatches > ", maxGenomicMatches2Mismatches, ": ",  sum(fragments$genomicMatches2Mismatches > maxGenomicMatches2Mismatches),"\n")
    fragments <- fragments[fragments$genomicMatches2Mismatches<=maxGenomicMatches2Mismatches,]
  }
  
  cat("Kept fragments: ", nrow(fragments), "\n")
  
  return(fragments)
}