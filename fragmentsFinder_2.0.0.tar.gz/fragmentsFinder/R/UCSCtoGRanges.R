UCSCtoGRanges <-
function(UCSC){
     zoom <- unlist(strsplit(UCSC,"-|:"))
     names(zoom)<-c("chr","start","end")
     zoom<-as.list(zoom)
     for (i in 2:length(zoom)) {zoom[[i]]<-as.numeric(zoom[[i]])}
     GR<-GRanges(seqnames=zoom[[1]],ranges=IRanges(zoom[[2]],zoom[[3]]))
     return(GR)
}
