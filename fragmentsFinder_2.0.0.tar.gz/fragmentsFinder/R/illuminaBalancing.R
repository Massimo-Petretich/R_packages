illuminaBalancing <- function(primers) {
if (sum(!is.na(primers)) < 2) stop("Supply at least 2 sequences")

lst <- primers[!is.na(primers)]

mx<-max(sapply(lst, function(x){length(unlist(strsplit(x,"")))}))
for (i in 1:length(lst)) {lst[[i]]<-paste0(lst[[i]], paste(rep("x", mx-length(unlist(strsplit(lst[[i]],"")))),collapse="") )}

cat("\nlength:", nchar(lst[[1]]), "bp\n\n",lst, "\n\n")

mat<-matrix(rep(NA,length(unlist(strsplit(lst[[1]],"")))*length(lst)), nrow=length(lst) )
for(i in 1:length(lst)) {mat[i,]<-unlist(strsplit(lst[[i]],""))}

print(mat) 

mat2<-ifelse(mat=="A" | mat=="C", "AC", ifelse(mat=="G" | mat=="T", "GT", "x"))

print(mat2)

smmry<-matrix(rep(NA, length(unlist(strsplit(lst[[1]],"")))*2), nrow=2)
rownames(smmry)<-c("AC","GT")

smmry[1,]<-apply(mat2, function(x){sum(x=="AC")}, MARGIN=2)
smmry[2,]<-apply(mat2, function(x){sum(x=="GT")}, MARGIN=2)

return(smmry)
}
