fragmentSummaryPart1 <- function(fragments, ...) {
  
  fragments$GC        <- sapply(1:nrow(fragments), function(i) sum(alphabetFrequency(DNAString(fragments$primerPattern1[i]))[c(2,3)]) )
  fragments$AT        <- sapply(1:nrow(fragments), function(i) sum(alphabetFrequency(DNAString(fragments$primerPattern1[i]))[c(1,4)]) )
  fragments$percGC    <- sapply(1:nrow(fragments), function(i) round(sum(alphabetFrequency(DNAString(fragments$primerPattern1[i]))[c(2,3)])*100/nchar(fragments$primerPattern1[i]), 2) )
  fragments$primerPattern1Length <- sapply(fragments$primerPattern1, nchar)
  
  if(!all(fragments$primerPattern1Length >= 14)) {cat("Tm calculations may be inaccurate due to primers shorter than 14bp \nfragments: ", rownames(fragments)[fragments$primerPattern1Length <= 14], "\n")}
  
  fragments$Tmoriginal <- sapply(1:nrow(fragments), function(i) round(64.9 + (41*(fragments$GC[i]-16.4))/fragments$primerPattern1Length[i], 2))
  fragments$Tm <- fragments$Tmoriginal * 1.101
  fragments$Tm <- round(fragments$Tm, 2)
  
  fragments$fragmentLength <- fragments[, "end"] - fragments[, "start"]
  
  
  return(fragments)
}
