matchAnalysis <- function(dict0, genome, ...) {
	argnames <- names(list(...)); addArgs <- list(...)
	mismatches 	<- ifelse("max.mismatch" %in% argnames, ifelse(is.numeric(addArgs$max.mismatch), addArgs$max.mismatch, 0), 0)
	cores    	<- ifelse("cores" %in% argnames, ifelse(addArgs$cores >= 1, addArgs$cores, 1), 1)

	hits <- mclapply(seqnames(genome), matchPatternDataFrame, dict0=dict0,genome=genome, mismatches=mismatches, mc.cores=cores)
	return(do.call("rbind", hits))
}
