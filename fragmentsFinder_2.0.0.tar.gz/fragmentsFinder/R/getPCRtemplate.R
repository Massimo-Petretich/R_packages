getPCRtemplate <- function(fragments, pattern1, range, genome, ...) {
  
  argnames <- names(list(...)); addArgs <- list(...)
  flankingPattern1 <- ifelse("flankingPattern1" %in% argnames, ifelse(is.numeric(addArgs$flankingPattern1), addArgs$flankingPattern1, 5), 5)
  
  pattern1SiteLength <- flankingPattern1 + max(sapply(fragments$primerPattern1, nchar))
  
  nonReadingPrimerDistance <- ifelse("nonReadingPrimerDistance" %in% argnames, ifelse(is.numeric(addArgs$nonReadingPrimerDistance), addArgs$nonReadingPrimerDistance, 100), 100)
  
  rgDF <- as(UCSCtoGRanges(range), "data.frame"); rgDF$seqnames <- as.character(rgDF$seqnames)
  chrI <- eval(parse(text=paste("genome$",noquote(rgDF[1,1]), sep="")))
  
  fragments$PCRtemplate <- rep(NA, times=nrow(fragments))
  
  for (i in 1:nrow(fragments)) {
    if(fragments$patternStart[i] == pattern1) { 
      if(nonReadingPrimerDistance > fragments$end[i] - fragments$start[i] - nchar(fragments$primerPattern1[1])) {
        fragments$PCRtemplate[i] <- as.character(reverseComplement(DNAString(
          paste0(chrI[(fragments$start[i] + pattern1SiteLength):(fragments$end[i])], chrI[fragments$start[i]:(fragments$start[i] + pattern1SiteLength - 1)])
        )))
      }
      else {
        fragments$PCRtemplate[i] <- as.character(reverseComplement(DNAString(
          paste0(chrI[((fragments$end[i]) - nonReadingPrimerDistance + 1):(fragments$end[i])], chrI[fragments$start[i]:(fragments$start[i] + pattern1SiteLength - 1)])
        )))
      }
    }
    else {  
      if(nonReadingPrimerDistance > fragments$end[i] - fragments$start[i] - nchar(fragments$primerPattern1[1])) {
        fragments$PCRtemplate[i] <- paste0(chrI[(fragments$end[i] - pattern1SiteLength + 1):(fragments$end[i])], chrI[fragments$start[i]:(fragments$end[i] - pattern1SiteLength)])
      }
      else {
        fragments$PCRtemplate[i] <- paste0(chrI[(fragments$end[i] - pattern1SiteLength + 1):(fragments$end[i])], chrI[fragments$start[i]:(fragments$start[i] + nonReadingPrimerDistance - 1)])
      }
    }
  }
  return(fragments)
  
}