fragmentSummaryPart2 <- function(fragments, genome, ...) {
  
  primers <- DNAStringSet(fragments$primerPattern1)
  names(primers) <- rownames(fragments)
    
  hits <- matchAnalysis(primers, genome, ...)
  fragments$undetermined <-rep(NA, times=nrow(fragments))
  for (i in 1:nrow(fragments)) {fragments$undetermined[i] <- sum(hits$patternID==rownames(fragments)[i])}
  
  argnames <- names(list(...)); addArgs <- list(...)
  if ("max.mismatch" %in% argnames){ if(is.numeric(addArgs$max.mismatch)) {
    colnames(fragments)[grep("undetermined", colnames(fragments))] <- paste0("genomicMatches",addArgs$max.mismatch, "Mismatches")
  }
  else {colnames(fragments)[grep("undetermined", colnames(fragments))] <- "genomicMatches"}
  }
  else {colnames(fragments)[grep("undetermined", colnames(fragments))] <- "genomicMatches"}
  
  return(fragments)
}
