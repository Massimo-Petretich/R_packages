primersCheck <- function (primers, genome, ...) {
    argnames <- names(list(...))
    addArgs <- list(...)
    mismatches <- ifelse("max.mismatch" %in% argnames, ifelse(is.numeric(addArgs$max.mismatch), addArgs$max.mismatch, 0), 0)
    
	primersNoNa<- primers[!is.na(primers) & !duplicated(primers)]
	primersDSS <- DNAStringSet(primersNoNa)
    names(primersDSS) <- primersNoNa
    
	hits <- matchAnalysis(primersDSS, genome, ...)
    hitsTab <- table(hits$patternID)
	tab <- as.vector(hitsTab)
	names(tab) <- names(hitsTab)
	if (length(tab) < length(primersNoNa)) stop("One or more sequences had no hits")

	tab<-tab[order(names(tab))]
	ord<-order(order(primersNoNa))
	tab<-tab[ord]
	
	tabFinal <- rep(NA,length(primers))
	tabFinal[which(!is.na(primers) & !duplicated(primers))] <- tab
	names(tabFinal)[!is.na(primers) & !duplicated(primers)] <- names(tab)

	return(tabFinal)
}
